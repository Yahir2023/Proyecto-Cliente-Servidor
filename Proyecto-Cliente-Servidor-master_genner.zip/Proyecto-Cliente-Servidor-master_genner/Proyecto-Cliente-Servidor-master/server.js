require("dotenv").config();
const express = require("express");
const cors = require("cors"); // Importar CORS
const { connection: db } = require("./config/config.db"); // Importar la configuración de la base de datos

const app = express();
app.use(cors()); // Habilitar CORS para evitar bloqueos en el frontend
app.use(express.json());

// Ruta para obtener los usuarios registrados
app.get("/usuarios", (req, res) => {
    const query = "SELECT id_usuario, nombre, apellido, correo FROM usuarios";
    db.query(query, (err, results) => {
        if (err) {
            return res.status(500).json({ success: false, message: "Error en el servidor" });
        }
        res.json({ success: true, usuarios: results });
    });
});

// Ruta para editar el perfil del usuario
app.put("/editar-perfil", (req, res) => {
    const { correo, nombre, apellido, nuevaContraseña } = req.body;

    // Asegurarnos de que el correo y la contraseña se proporcionen
    if (!correo || !nombre || !apellido || !nuevaContraseña) {
        return res.status(400).json({ success: false, message: "Todos los campos son requeridos" });
    }

    // Actualizar los datos del perfil en la base de datos
    const query = "UPDATE usuarios SET nombre = ?, apellido = ?, contraseña = ? WHERE correo = ?";
    db.query(query, [nombre, apellido, nuevaContraseña, correo], (err, results) => {
        if (err) {
            return res.status(500).json({ success: false, message: "Error al actualizar el perfil" });
        }
        if (results.affectedRows > 0) {
            res.json({ success: true, message: "Perfil actualizado correctamente" });
        } else {
            res.status(404).json({ success: false, message: "Usuario no encontrado" });
        }
    });
});

// Ruta para editar una función (solo admin)
app.put("/editar-funcion", (req, res) => {
    const { correo, funcionId, nuevaHora, nuevaSala } = req.body;

    // Verificar si el correo corresponde al admin
    if (correo === "yahiradmin@gmail.com") {
        // Actualizar la función en la base de datos
        const query = "UPDATE funciones SET hora = ?, sala = ? WHERE id = ?";
        db.query(query, [nuevaHora, nuevaSala, funcionId], (err, results) => {
            if (err) {
                return res.status(500).json({ success: false, message: "Error al editar la función" });
            }
            if (results.affectedRows > 0) {
                res.json({ success: true, message: "Función de cine editada exitosamente" });
            } else {
                res.status(404).json({ success: false, message: "Función no encontrada" });
            }
        });
    } else {
        // Si no es el admin
        res.status(403).json({ success: false, message: "No tienes permisos para editar funciones" });
    }
});

// Iniciar servidor en puerto 3000 o el definido en el .env
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://127.0.0.1:${PORT}`);
});
