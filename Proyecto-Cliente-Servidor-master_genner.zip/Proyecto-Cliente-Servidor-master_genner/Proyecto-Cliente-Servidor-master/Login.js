require("dotenv").config();
const express = require("express");
const bodyParser = require("body-parser");
const { connection: db } = require("./config/config.db");

const app = express();
app.use(bodyParser.json());

// Ruta para inicio de sesión
app.post("/login", (req, res) => {
    const { correo, contraseña } = req.body;

    // Validación de credenciales del admin
    if (correo === "yahiradmin@gmail.com" && contraseña === "1234") {
        return res.json({
            success: true,
            message: "Inicio de sesión exitoso",
            user: {
                correo,
                rol: "admin"
            }
        });
    }

    // Verificación de credenciales en la base de datos para usuarios comunes
    const query = "SELECT nombre, apellido, correo FROM usuarios WHERE correo = ? AND contraseña = ?";
    db.query(query, [correo, contraseña], (err, results) => {
        if (err) {
            return res.status(500).json({ success: false, message: "Error en el servidor" });
        }
        if (results.length > 0) {
            res.json({ success: true, message: "Inicio de sesión exitoso", user: results[0] });
        } else {
            res.status(401).json({ success: false, message: "Credenciales incorrectas" });
        }
    });
});

// Ruta para editar funciones de cine (solo puede hacerlo el admin)
app.put("/editar-funcion", (req, res) => {
    const { correo, funcionId, nuevaHora, nuevaSala } = req.body;

    // Verificar si el correo corresponde al admin
    if (correo === "yahiradmin@gmail.com") {
        // Aquí va la lógica para editar la función de cine en la base de datos
        const query = "UPDATE funciones SET hora = ?, sala = ? WHERE id = ?";
        db.query(query, [nuevaHora, nuevaSala, funcionId], (err, results) => {
            if (err) {
                return res.status(500).json({ success: false, message: "Error al editar la función" });
            }
            if (results.affectedRows > 0) {
                res.json({ success: true, message: "Función de cine editada exitosamente" });
            } else {
                res.status(404).json({ success: false, message: "Función no encontrada" });
            }
        });
    } else {
        // Si no es el admin
        res.status(403).json({ success: false, message: "No tienes permisos para editar funciones" });
    }
});

// Ruta para editar el perfil de usuario (solo puede hacerlo el usuario autenticado)
app.put("/editar-perfil", (req, res) => {
    const { correo, nuevoNombre, nuevoApellido } = req.body;

    // Verificar si el usuario está autenticado
    const query = "UPDATE usuarios SET nombre = ?, apellido = ? WHERE correo = ?";
    db.query(query, [nuevoNombre, nuevoApellido, correo], (err, results) => {
        if (err) {
            return res.status(500).json({ success: false, message: "Error al editar el perfil" });
        }
        if (results.affectedRows > 0) {
            res.json({ success: true, message: "Perfil actualizado exitosamente" });
        } else {
            res.status(404).json({ success: false, message: "Usuario no encontrado" });
        }
    });
});

// Iniciar servidor
const PORT = 3000;
app.listen(PORT, () => {
    console.log('El servidor escucha en el puerto ' + PORT);
});